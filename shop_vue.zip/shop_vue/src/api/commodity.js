import axios from "axios"
export const getClassifyList=(shop_id)=>axios.get("product/shop_category_lists",{params:{shop_id}})

export const SaveShopClassifyList =(existMess)=>axios.post("product/save_shop_category",existMess)

export const onoffBatch =(data)=>axios.put("product/onoff_batch",data)

export const deleteBatch =(data)=>axios.put("product/delete_batch",data)

export const checkProduct =(product_id)=>axios.get("product/get",{params:{product_id}})

export const keepCategoryMess=(keepMess)=>axios.put("product/update",keepMess)

export const editspef=(Mess)=>axios.post("product/save_spec",Mess)

export const setProductsCategory =(data)=>axios.post("product/save_product_shop_category_batch",data)//批量设置商品店铺分类

export const setOnlyProductsCategory =(data)=>axios.post("product/save_product_shop_category",data)//设置商品店铺分类(单个)

export const getShippingTem =(data)=>axios.post("shop/distribute_template_lists",data)

export const createProduct =(data)=>axios.post("product/create",data)

export const getBrandList=()=>axios.get("product/mall_brand_lists")

export const getBrand=(id)=>axios.get("product/mall_brand_get/"+id)

export const brandCreate=(data)=>axios.post("product/mall_brand_create",data)

export const brandUpdate=(data,id)=>axios.put("product/mall_brand_update/"+id,data)

export const brandChange=(data,id)=>axios.patch("product/mall_brand_change/"+id,data)

export const brandDelete=(ids)=>axios.delete("product/mall_brand_delete",{params:{ids}})

export const setProductsBrand=(data,id)=>axios.post("product/mall_brand_set/"+id,data)

export const changeSort=(data)=>axios.post("product/mall_brand_change",data)
