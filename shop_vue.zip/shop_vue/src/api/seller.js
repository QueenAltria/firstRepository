import axios from 'axios'
export const getMallData =(mall_id)=>axios.get("seller/get_mall_statistics",{params:{mall_id}})//获取商城统计数据

export const getshopDynamics=(data)=>axios.post("seller/operate_log_lists",data)//获取店铺动态列表

export const getDynamicsNum=(data)=>axios.get("seller/get_shop_pending_num",{params:data})//获取店铺待处理事件数量

export const getMallNum=(data)=>axios.post("seller/get_mall_statistics_chart",data)//获取商城统计图数据
