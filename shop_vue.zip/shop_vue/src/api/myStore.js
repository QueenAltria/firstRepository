import axios from "axios";

export const imageUpload =(file)=>axios.post("upload_image",file)/*上传图片接口*/

export const createStoreMess=(storeMess)=>axios.post("shop/create",storeMess)

export const getUserMess=(mall_id)=>axios.get("user/get_shop",{params:{mall_id}})

export const getstoreMess=(shop_id)=>axios.get("shop/get",{params:{shop_id}})

export const keepStoreMess=(keepMess)=>axios.put("shop/update",keepMess)

export const existStoreMess=(existMess)=>axios.post("shop/save_decoration",existMess)

export const getStoreBanner=(shop_id)=>axios.get("shop/get_banner",{params:{shop_id}})

export const getProductList=(shopMess)=>axios.post("product/lists",shopMess)//商品列表信息

export const getfreightTemList=(data)=>axios.post("shop/distribute_template_lists",data)//运费模板列表

export const addFreightTem=(data)=>axios.post("shop/create_distribute_template",data)//添加运费模板

export const editFreightTem=(data)=>axios.put("shop/update_distribute_template",data)//编辑运费模板

export const delFreightTem=(data)=>axios.delete("shop/delete_distribute_template",{data})//编辑运费模板

export const existFreeShipping=(data)=>axios.post("mall_set/save_baoyou",data)//保存订单包邮设置

export const seeFreeShipping=(mall_id)=>axios.get("mall_set/get_baoyou",{params:{mall_id}})//查看订单包邮设置
