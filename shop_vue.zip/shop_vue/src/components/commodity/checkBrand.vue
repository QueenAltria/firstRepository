<template>
	<div class="checkClassify text-l ">
	    <label class="display-b store_label cursor" v-for="(item,index) in brandList" :key="index">  	
			<input type="radio" name="two" class="display-n" @change="checkedIndex(item,index)" :checked="isCheck(item)">			
			<em></em>
			{{item.brand_name}}
		</label>
	</div>
</template>

<script>

	export default{
		data(){
			return{
				brandList: []
			}
		},
		props:{
			checkedBrand:{
				type: Number,
				default:function(){
					return 0
				}		
			},
		},
		created() {
			this.brandList = this.$store.getters.getBrandList;
		},
		methods:{
			checkedIndex(item,index){	
				this.$emit("brandCheck",item.id);
			},
			isCheck(item) {

		      if(this.checkedBrand <= 0) {
		        return false
		      }
		      return this.checkedBrand == item.id
		    }
		}
	}
</script>
