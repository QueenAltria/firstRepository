export default{
	computed:{
		//店铺分类信息
		storeClassify(){
			var classifyList=this.$store.getters.getClassifyList;
			var classify=[];
			var that=this;			
			classifyList.map(item=>{
				if(item.is_final===0){
					classify.push({
						shop_category_name:item.shop_category_name,
						level:item.level,
						is_final:item.is_final,
						id:item.id,
						checked:false
					})
					item.sub.map(itemSub=>{
						classify.push({
							shop_category_name:itemSub.shop_category_name,
							level:itemSub.level,
							is_final:item.is_final,
							id:itemSub.id,
							checked:false
						})
					})
				}else if(item.is_final===1){
					classify.push({
						shop_category_name:item.shop_category_name,
						level:item.level,
						is_final:item.is_final,
						id:item.id,
						checked:false
					})
				};
			});
			return  classify
		},
	},
}
