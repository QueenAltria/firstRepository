import Vue from 'vue'
import parse from 'url-parse'
import store from '@/store'
import Router from 'vue-router'
import login from '@/pages/login'
import forgetMess from '@/pages/login_errorPage/forgetMess'
import mobileReset from '@/pages/login_errorPage/mobileReset'
import emailReset from '@/pages/login_errorPage/emailReset'
import register from '@/pages/login_errorPage/register'
import weixin from '@/pages/login_errorPage/weixin'

import zxh from '@/pages/zxh'
import storeInfo from '@/pages/myStorePage/storeInfo'
import addMess from '@/pages/myStorePage/addMess'
import storeMessShow from '@/pages/myStorePage/storeMessShow'
import freightSetting from '@/pages/myStorePage/freightSetting'
import shop_decoration from '@/pages/myStorePage/shop_decoration'
import my_store_blank from '@/pages/myStorePage/my_store_blank'

import commodityInfo from '@/pages/commodityPage/commodityInfo'
import category_mgmt from '@/pages/commodityPage/category_mgmt'
import sale_commodity from '@/pages/commodityPage/sale_commodity'
import pulishProduct from '@/pages/commodityPage/pulishProduct'
import warehouse from '@/pages/commodityPage/warehouse'
import history from '@/pages/commodityPage/history'
import category from '@/pages/commodityPage/category'

import brand from '@/pages/commodityPage/brand'
import brandProduct from '@/pages/commodityPage/brandProduct'

import allOrder from '@/pages/order/allOrder'
import nonPayment from '@/pages/order/non_payment'
import UnshippedOrder from '@/pages/order/UnshippedOrder'
import PendingOrder from '@/pages/order/PendingOrder'
import CompletedOrder from '@/pages/order/CompletedOrder'
import cancelledOrder from '@/pages/order/cancelledOrder'
import refundOrder from '@/pages/order/refundOrder'

import marketInfo from '@/pages/marketingPage/marketInfo'
import Coupon from '@/pages/marketingPage/Coupon'
import memberCenter from '@/pages/marketingPage/memberCenter'
import sellerCenter from '@/pages/sellerCenter/sellerCenter'

Vue.use(Router)

const router = new Router({
	routes: [{
		path: '/',
		name: 'login',
		component: login
	}, {
		path: '/login_errorPage/forgetMess',
		name: 'forgetMess',
		component: forgetMess
	}, {
		path: '/login_errorPage/mobileReset',
		name: 'mobileReset',
		component: mobileReset
	}, {
		path: '/login_errorPage/emailReset',
		name: 'emailReset',
		component: emailReset
	}, {
		path: '/login_errorPage/register',
		name: 'register',
		component: register
	}, {
		path: '/login_errorPage/weixin',
		name: 'weixin',
		component: weixin
	}, {
		path: '/zxh',
		name: 'zxh',
		component: zxh,
		children: [{
				path: 'my_store_blank',
				component: my_store_blank,
				name: "my_store_blank",
				children: [{
					path: 'storeInfo',
					component: storeInfo,
					name: "storeInfo"
				}, {
					path: 'addMess',
					component: addMess,
					name: "addMess"
				}, {
					path: 'storeMessShow',
					component: storeMessShow,
					name: "storeMessShow"
				}, {
					path: 'shop_decoration',
					component: shop_decoration,
					name: "shop_decoration"
				}, {
					path: 'freightSetting',
					component: freightSetting,
					name: "freightSetting"
				}]

			}, {
				path: 'commodityPage',
				name: 'commodity',
				component: my_store_blank,
				children: [{
					path: 'commodityInfo',
					component: commodityInfo,
					name: "commodityInfo"
				}, {
					path: 'category_mgmt',
					component: category_mgmt,
					name: "category_mgmt"
				}, {
					path: "sale_commodity",
					component: sale_commodity,
					name: "sale_commodity"
				}, {
					path: "pulishProduct",
					component: pulishProduct,
					name: "pulishProduct"
				}, {
					path: "warehouse",
					component: warehouse,
					name: "warehouse"
				}, {
					path: "history",
					component: history,
					name: "history"
				}, {
					path: "category",
					component: category,
					name: "category"
				}, {
					path: "brand",
					component: brand,
					name: "brand"
				}, {
					path: "brand_product",
					component: brandProduct,
					name: "brand_product"
				}]
			},
			{
				path: 'orderPage',
				name: 'orderPage',
				component: my_store_blank,
				children: [{
						path: 'allOrder',
						component: allOrder,
						name: "allOrder"
					},
					{
						path: 'nonPayment',
						component: nonPayment,
						name: "nonPayment"
					},
					{
						path: 'UnshippedOrder',
						component: UnshippedOrder,
						name: "UnshippedOrder"
					},
					{
						path: 'PendingOrder',
						component: PendingOrder,
						name: "PendingOrder"
					},
					{
						path: 'CompletedOrder',
						component: CompletedOrder,
						name: "CompletedOrder"
					},
					{
						path: 'cancelledOrder',
						component: cancelledOrder,
						name: "cancelledOrder"
					},
					{
						path: 'refundOrder',
						component: refundOrder,
						name: "refundOrder"
					},
				]
			},
			{
				path: 'marketingPage',
				name: 'marketingPage',
				component: my_store_blank,
				children: [{
						path: 'marketInfo',
						component: marketInfo,
						name: "marketInfo"
					},
					{
						path: 'Coupon',
						component: Coupon,
						name: "Coupon"
					}, {
						path: 'memberCenter',
						component: memberCenter,
						name: "memberCenter"
					}
				]
			},
			{
				path: 'sellerPage',
				name: 'sellerPage',
				component: my_store_blank,
				children: [{
					path: 'sellerCenter',
					component: sellerCenter,
					name: "sellerCenter"
				}]
			}
		]
	}]
})

router.beforeEach((to, from, next) => {
	if(to.path === '/') {
		if(store.state.user.login) {
			if(to.query.redirect) {
				let parsed = parse(decodeURIComponent(to.query.redirect), true)
				if(parsed.pathname === to.path) {
					next()
				} else {
					next({
						path: parsed.pathname,
						query: parsed.query
					})
				}

			} else {
				next({
					path: '/zxh/my_store_blank/storeInfo'
				})
			}
		} else {

			next();
		}
	} else if(store.state.user.login) {
		if(from.query.redirect) {
			let parsed = parse(decodeURIComponent(from.query.redirect), true)
			if(parsed.pathname === to.path) {
				next()
			} else {
				next({
					path: parsed.pathname,
					query: parsed.query //目前没有查询参数，可以不需要
				})
			}
		} else {
			next()
		}
	} else {
		switch(true) {
			case to.path === "/login_errorPage/forgetMess":
				next();
				break;
			case to.path === "/login_errorPage/mobileReset":
				next();
				break;
			case to.path === "/login_errorPage/emailReset":
				next();
				break;
			case to.path === "/login_errorPage/register":
				next();
				break;
			case to.path === "/login_errorPage/weixin":
				next();
				break;
			default:
				next({
					path: '/',
					query: {
						redirect: encodeURIComponent(to.fullPath)
					}
				})
		}
	}
})

export default router