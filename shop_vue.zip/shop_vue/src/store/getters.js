/* the root getters */
