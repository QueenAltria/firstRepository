import * as types from "../mutation-types"
import {getClassifyList,getBrandList} from "@/api/commodity"

const state={
	classifyList:[],
	brandList: []
}
const getters={
	getClassifyList:(state)=>{
		return state.classifyList
	},
	getBrandList:(state)=>{
		return state.brandList
	}
}
const mutations={
	[types.CLASSIFYLIST](state,data){
		state.classifyList=data;
	},
	[types.BRANDLIST](state,data){
		state.brandList=data;
	},
}
const actions={
	doClassifyList({commit},shop_id){
		//获取店铺分类列表
		getClassifyList(shop_id)
		.then(({data})=>{
			commit(types.CLASSIFYLIST,data)
		}).catch((error)=>{
			console.log(error)
		})
	},
	doBrandList({commit}){
		//获取店铺分类列表
		getBrandList()
		.then(({data})=>{
			commit(types.BRANDLIST,data)
		}).catch((error)=>{
			console.log(error)
		})
	}
}
export default {
	state,getters,mutations,actions
}
