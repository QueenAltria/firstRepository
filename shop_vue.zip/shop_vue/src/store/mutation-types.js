export const LOGIN = 'LOGIN'
export const LOGOUT = 'LOGOUT'
export const FRORGETMESS='FRORGETMESS'
export const LOGINURL='LOGINURL'
export const RESETSUCCESS='RESETSUCCESS'
export const REGISTERSUCCESS='REGISTERSUCCESS'

export const GETSHOPID="GETSHOPID"
export const MESSLENGTH="MESSLENGTH"
export const KEEPSUCESS="KEEPSUCESS" //保存成功提示

export const ADDSUCESS="ADDSUCESS" //添加成功提示

export const SHOWBOMB="SHOWBOMB" //店铺装修弹框显示
export const CLASSIFYLIST="CLASSIFYLIST"//店铺分类列表
export const BRANDLIST="BRANDLIST"//店铺分类列表

export const KEEPDESC="KEEPDESC"//店铺装修保存弹框显示
export const PUBLISHMESS="PUBLISHMESS" //发布信息集合



