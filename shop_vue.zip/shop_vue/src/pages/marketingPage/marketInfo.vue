<template>
	<div>
		<div class="info_content clearfix">
			<router-link :to="{name:'Coupon'}" class="item-1 item-list fl">
				<div>
					<i class="iconfont icon-dianpuyouhuiquan" style="font-size: 50px;"></i>
					<span>店铺优惠券</span>
				</div>
				<p><i class="iconfont icon-dianpuyouhuiquan" style="font-size: 100px;"></i></p>
			</router-link>
			<router-link :to="{name:'memberCenter'}" class="item-2 item-list fl">
				<div>
					<i class="iconfont icon-huiyuanzhongxin"></i>
					<span>会员中心</span>
				</div>
				<p><i class="iconfont icon-huiyuanzhongxin" style="font-size: 110px;"></i></p>
			</router-link>
			<!--<router-link :to="{name:'pulishProduct'}" class="item-3 item-list fl">
				<div>
					<i class="iconfont icon-fenxiaozhongxin"></i>
					<span>分销中心</span>
				</div>
				<p><i class="iconfont icon-fenxiaozhongxin" style="font-size: 110px;"></i></p>
			</router-link>-->
		</div>
	</div>
</template>

<script>
</script>

<style>

</style>