<template>
	<div class="pulishProduct">
		<Navbar></Navbar>
		<productMess></productMess>
	</div>
</template>

<script>
	import Navbar from "@/components/commodity/Navbar"
	import productMess from "@/components/commodity/productMess"

	export default{
		data(){
			return{
			}
		},
		components:{
			Navbar,productMess
		},
		methods:{
		}
	}
</script>

<style lang="scss">

</style>



