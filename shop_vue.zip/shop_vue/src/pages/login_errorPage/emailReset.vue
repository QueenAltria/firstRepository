<template>
	<div class="login pos-r text-c">
		<img :src="loginUrl.background" class="w-100 background"/>
		<div class="login-con middle pl-20 pr-20">
			<img  :src="loginUrl.logo" class="logo pt-20" height="100" width="100"/>	
			<div class="login-box pt-20">
				<el-row >
					<transition name="el-fade-in" mode="out-in">
						<el-button v-if="warn" v-html="msg"  class="waring mb-20 display-in"></el-button>
					</transition>
				</el-row>
				<el-row>
					<el-input type="text" placeholder="请输入你账号绑定的邮箱" v-model.trim="email" class="login-input2" :class="{border:borderOne}">
																
					</el-input>
				</el-row>
				<el-row :gutter="10">
					<el-col :span="16" class="pt-20">
						<el-input type="text" placeholder="邮箱验证码" v-model.trim="verify_code" class="login-input2" :class="{border:borderTwo}"></el-input>				
					</el-col>
					<el-col :span="8" class="pt-20">
						<el-button @click="sentCode" :disabled="disabled || time>0" class="login-button pt-20 disabled1">{{sentEmailCode}}</el-button>
					</el-col>
				</el-row>
				<el-row>
					<el-input type="password" placeholder="请输入新密码" v-model.trim="newPassword" class="login-input2 pt-20" :class="{border:borderThree}">
																
					</el-input>
				</el-row>
				<el-row>
					<el-input type="password" placeholder="请再输入一遍新密码" v-model.trim="repeatPassword" class="login-input2 pt-20" :class="{border:borderFour}">
																
					</el-input>
				</el-row>
				<el-row class="mt-20 pb-20">
					<el-button  class="w-100 login-button display-b" @click="resetMess">
						重置密码
					</el-button>
				</el-row>
				<router-link to="/" class="f12 padding-n mb-20 color-b display-b">←返回登录页</router-link>
			</div>
		</div>
	</div>
</template>

<script>
	import {getphoneEmailCode,getEmailNum,getEmailReset} from '@/api/login'
	import router from '@/router'
	export default {
		name: 'forgetMess',  
		data (){
		 	return{
		 		msg:"",
		 		email:"",
		 		verify_code:"",
		 		newPassword:"",
		 		repeatPassword:"",
		 		warn:false,
		 		borderOne:false,
		 		borderTwo:false,
		 		borderThree:false,
		 		borderFour:false,
		 		time:0
		 	}
		 },
		 props:{
			disabled:{
				type:Boolean,
				default:false
			},
			second:{
				type:Number,
				default:60
			}
		 },
		created:function(){
				this.$store.dispatch("doLoginURL");
		},
		computed:{
			loginUrl(){							 	
				return this.$store.getters.getLoginUrl
			},
			sentEmailCode(){
				return this.time>0?"重新发送("+this.time+"s)":"发送验证码"
			}
		},
		methods:{
			sentCode:function(){
				this.borderOne=false;
				this.msg="";
				var patt1=/^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/;
				switch(true){
					case this.email=="":
						this.borderOne=true;
						this.warn=true;
						this.msg="请输入你账号绑定的邮箱";
						break;
					case !patt1.test(this.email)&&this.email!=="":
						this.borderOne=true;
						this.warn=true;
						this.msg="请输入正确的邮箱";
						break;
					case patt1.test(this.email):						
						getphoneEmailCode("email",this.email)
						.then(({data})=>{							
							this.time=this.second;
							this.timer();
						})
						.catch(({response:{data}})=>{
							console.log(data);
							this.warn=true;
							this.msg=data.errorcmt;
						})
						break;
				}
			},
			timer:function(){
				//60s
				if(this.time>0){
					this.time--;
					setTimeout(this.timer,1000)
				}
			},
			resetMess:function(){
				//直接点击重置密码邮箱以及格式不对也显示
				let arr1=["borderOne","borderOne","borderOne","borderOne"];
				this.isBoolean(arr1,false)
				this.msg="";
				var patt1=/^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/;
				switch(true){
					case this.email=="":
						this.borderVis();
						this.msg="请输入你账号绑定的邮箱";
						break;
					case !patt1.test(this.email):
						this.borderVis();
						this.msg="请输入正确的邮箱";
						break;					
				}
				//输入账号绑定邮箱之后的判断
				if(patt1.test(this.email)){
					getEmailNum(this.email)
					.then(({data})=>{
						//未存在邮箱提示未绑定
						console.log(data.data)
						if(data.exists==0){
							this.borderVis();
							this.msg="该邮箱尚未绑定任何账号";
						};
						//存在接着往下走，写这里为不同时出现两个错误提示
						if(data.exists==1){
							switch(true){
								case this.verify_code=="":													
									let arr3=["warn","borderOne"];
									this.isBoolean(arr3,false)
									let arr4=["warn","borderTwo"];
									this.isBoolean(arr4,true)
									this.msg="请输入邮箱验证码";						
									break;
								case this.newPassword=="":
									let arr5=["warn","borderOne","borderTwo"];
									this.isBoolean(arr5,false);
									let arr6=["warn","borderThree"];
									this.isBoolean(arr6,true);
									this.msg="请输入新密码";						
									break;
								case this.repeatPassword=="":
									let arr7=["warn","borderOne","borderTwo","borderThree"];
									this.isBoolean(arr7,false);
									let arr8=["warn","borderFour"];
									this.isBoolean(arr8,true);
									this.msg="请再输入一遍新密码";						
									break;
								case this.newPassword!==this.repeatPassword:
									let arr9=["borderOne","borderTwo"];
									this.isBoolean(arr9,false);
									let arr10=["borderThree","borderFour","warn"];
									this.isBoolean(arr10,true);
									this.msg="两次密码输入不同，请修改后尝试";						
									break;
								default:
									getEmailReset(this.email,this.verify_code,this.newPassword)
									.then(({data})=>{						
										router.replace("/");
										this.$store.dispatch("doResetSuccess",true);
									})
									.catch(({response:{data}})=>{
										this.warn=true;
										this.msg=data.errorcmt
									})
							}
						}
					})
					.catch(({response:{data}})=>{
						console.log(222)
						//发送验证码时的错误提示
						this.warn=true;
						this.msg=data.errorcmt;		
					})	
				}
				
			},
			borderVis(){
				let arr2=["borderOne","warn"];
				this.isBoolean(arr2,true);
			},
			isBoolean(isArrt,booleans){
				isArrt.map(item=>this[item]=booleans)
			}
		}
	}
</script>

<style lang="scss">
	.login{
		width: 100%;
		max-width: 1920px;
		margin: 0 auto;
		.background{
			position: fixed;
		    height: 100%;
		    width: 100%;
		    left: 0;
		    top: 0;
		}
	.middle{
		position: absolute;
		top: 128px;
		left: 50%;
		margin-left: -160px;
	}
	.login-con{
		background-color: #fff;
		width: 280px;
		border-radius: 6px;
		box-shadow: 0px 0px 4px 0px rgba(0,0,0,.3);	
		.login-box{
			.border{
				.el-input__inner{
					border:1px solid #FF5B00;
					}
			}
			.waring.el-button{
				&:visited{
					color: #333;
					border-color:#FF5B00;
				}
				&:hover{
					color: #333;
					border-color:#FF5B00;
				}
				&:active{
					color: #333;
					border-color:#FF5B00;
				}
				&:focus{
					color: #333;
					border-color:#FF5B00;
				}
			}
		}


	}
}
</style>