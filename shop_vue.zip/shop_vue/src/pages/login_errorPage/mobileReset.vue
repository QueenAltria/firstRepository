<template>
	<div class="login pos-r text-c">
		<img :src="loginUrl.background" class="background"/>
		<div class="login-con middle pl-20 pr-20">
			<img  :src="loginUrl.logo" class="logo pt-20" height="100" width="100"/>	
			<div class="login-box pt-20">									
				<el-row >
					<transition name="el-fade-in" mode="out-in">
						<el-button v-if="warn" v-html="msg" @click="register" class="waring mb-20 display-in"></el-button>
					</transition>
				</el-row>
				<el-row>
					<el-input type="text" placeholder="请输入注册时的手机号" v-model.trim="mobile_phone"  class="login-input2" :class="{border:borderOne}">															
					</el-input>
				</el-row>
				<el-row :gutter="10">
					<el-col :span="16" class="pt-20">
						<el-input type="text" placeholder="手机验证码" v-model.trim="verify_code" class="login-input2"  :class="{border:borderTwo}"></el-input>				
					</el-col>
					<el-col :span="8" class="pt-20">
						<el-button @click="sentCode" :disabled="disabled || time>0 " class="login-button pt-20 disabled1" >{{sentPhoneCode}}</el-button>
					</el-col>
				</el-row>
				<el-row>
					<el-input type="password" placeholder="请输入8-20位新密码" v-model.trim="newPassword"  class="login-input2 pt-20" :class="{border:borderThree}">
																
					</el-input>
				</el-row>
				<el-row>
					<el-input type="password" placeholder="请再输入一遍新密码" v-model.trim="repeatPassword" class="login-input2 pt-20" :class="{border:borderFour}">
																
					</el-input>
				</el-row>
				<el-row class="mt-20 pb-20">
					<el-button  class="w-100 login-button display-b" @click="resetMess">
						重置密码
					</el-button>
				</el-row>
				<router-link to="/" class="f12 padding-n mb-20 color-b display-b">←返回登录页</router-link>		
			</div>
		</div>
	</div>
</template>

<script>
	import {getPhoneNum,getphoneEmailCode,getPhoneAllMess} from '@/api/login'
	import router from '@/router'
	export default {
		name: 'forgetMess',  
		data (){
		 	return{
		 		warn:false,
		 		borderOne:false,
		 		msg:"",
		 		mobile_phone:"",
           		time:0,
           		verify_code:"",
           		borderTwo:false,
          		newPassword:"",
          		repeatPassword:"",
          		borderThree:false,
          		borderFour:false,
		 	}
		},
		props:{
			disabled:{
				type:Boolean,
				default:false
			},
			second:{
				type:Number,
				default:60
			}
		},
		created:function(){
				this.$store.dispatch("doLoginURL");
		  },
		computed:{
			loginUrl(){							 	
				return this.$store.getters.getLoginUrl
			},
			sentPhoneCode(){
				return this.time>0?"重新发送("+this.time+"s)":"发送验证码"
			}
		},
		methods:{
			register:function(){
				if(event.srcElement.nodeName==="SPAN"){
					console.log(router.currentRoute.path)
					if(router.currentRoute.path==="/login_errorPage/mobileReset"){
						if(event.srcElement.innerText==='"注册"'){
							router.replace("/login_errorPage/register")
						}
					}

				}
			},
			resetMess:function(){
				//点击重置密码
				let arr1=["borderOne","borderOne","borderOne","borderOne"];
				this.isBoolean(arr1,false)
				this.msg="";
				var patt1=/^[1][3,4,5,7,8][0-9]{9}$/;
				//手机号码是否存在然后处理其他错误
				if(patt1.test(this.mobile_phone)){
					getPhoneNum(this.mobile_phone)
					.then(({data})=>{				
						if(data.exists==0){
							let arr2=["warn","borderOne"];
							this.isBoolean(arr2,true)
							this.msg='该手机号码尚未注册，请先'+'<span class="cursor color-b register">'+'"注册"'+'</span>'
						}
						if(data.exists==1){
							switch(true){
								case this.verify_code=="":													
									let arr4=["warn","borderOne"];
									this.isBoolean(arr4,false);
									let arr3=["warn","borderTwo"];
									this.isBoolean(arr3,true);
									this.msg="请输入验证码";						
									break;
								case this.newPassword=="":
									this.borderVis();
									this.msg="请输入新密码";						
									break;
								case this.newPassword.length>20||this.newPassword.length<8:
									this.borderVis();
									this.msg="手机密码为8-20位";						
									break;
								
								case this.repeatPassword=="":
									this.borderVisTwo();
									this.msg="请再输入一遍新密码";						
									break;
								case this.repeatPassword.length>20||this.repeatPassword.length<8:
									this.borderVisTwo();
									this.msg="手机密码为8-20位";						
									break;
								case this.newPassword!==this.repeatPassword:
									let arr8=["borderThree","borderFour","warn"];
									this.isBoolean(arr8,true);
									this.msg="两次密码输入不同，请修改后尝试";						
									break;
								default:
									getPhoneAllMess(this.mobile_phone,this.verify_code,this.newPassword)
									.then(({data})=>{										
										router.replace("/");
										this.$store.dispatch("doResetSuccess",true);
									})
									.catch(({response:{data}})=>{
										//发送验证失败
										this.warn=true;			
										this.msg=data.errorcmt;									
									})
							}
						}
					})
					.catch(({response:{data}})=>{
						console.log("data444444444",data.errorcmt)
						//发送验证码时的错误提示
						this.warn=true;
						this.msg=data.errorcmt;		
					})	
				}
				//手机号码没填或者是格式错误
				switch(true){					
					case this.mobile_phone=="":
						this.warn=true;
						this.borderOne=true;
						this.msg="请输入你注册时的手机号"
						break;
					case !patt1.test(this.mobile_phone)&&this.mobile_phone!=="":
						this.warn=true;
						this.borderOne=true;
						this.msg="请输入正确的手机号"
						break;
				}
			},
			borderVis(){
				let arr5=["warn","borderOne","borderTwo"];
				this.isBoolean(arr5,false);
				let arr6=["warn","borderThree"];
				this.isBoolean(arr6,true);
			},
			borderVisTwo(){
				let arr9=["warn","borderOne","borderTwo","borderThree"];
				this.isBoolean(arr9,false);
				let arr7=["warn","borderFour"];
				this.isBoolean(arr7,true);
			},
			isBoolean(isArrt,booleans){
				isArrt.map(item=>this[item]=booleans)
			},
			sentCode:function(){
				//点击发送验证码
				this.borderOne=false;
				this.msg="";
				var patt1=/^[1][3,4,5,7,8][0-9]{9}$/;				
				switch(true){					
					case this.mobile_phone=="":
						this.warn=true;
						this.borderOne=true;
						this.msg="请输入你注册时的手机号"
						break;
					case !patt1.test(this.mobile_phone):
						this.warn=true;
						this.borderOne=true;
						this.msg="请输入正确的手机号";
						break;
					case patt1.test(this.mobile_phone):				
						getphoneEmailCode('phone',this.mobile_phone)
						.then((reponse)=>{	
							this.time=this.second;
							this.timer();
						})	
						.catch(({response:{data}})=>{
							//发送验证失败
							this.warn=true;			
							this.msg=data.errorcmt;									
						})
						break;
				}
			},
			timer:function(){
				//60s
				if(this.time>0){
					this.time--;
					setTimeout(this.timer,1000)
				}
			},
		},
	}
</script>

<style lang="scss">
	.login{
		width: 100%;
		max-width: 1920px;
		margin: 0 auto;
		.background{
			position: fixed;
		    height: 100%;
		    width: 100%;
		    left: 0;
		    top: 0;
		}
	.middle{
		position: absolute;
		top: 128px;
		left: 50%;
		margin-left: -160px;
	}
	.login-con{
		background-color: #fff;
		width: 280px;
		border-radius: 6px;
		box-shadow: 0px 0px 4px 0px rgba(0,0,0,.3);	
		.login-box{
			.border{
				.el-input__inner{
					border:1px solid #FF5B00;
					}
			}
			.waring.el-button{
				&:visited{
					color: #333;
					border-color:#FF5B00;
				}
				&:hover{
					color: #333;
					border-color:#FF5B00;
				}
				&:active{
					color: #333;
					border-color:#FF5B00;
				}
				&:focus{
					color: #333;
					border-color:#FF5B00;
				}
			}
		}


	}
}
</style>
<style></style>