<template>
	<div class="login pos-r">
		<img :src="loginUrl.background" class="background"/>
		<div class="login-con middle pl-20 pr-20">
			<div id="QRcode"></div>		
			<router-link to="/" class="f12 color-b display-b mb-20" >←返回登录页</router-link>
		</div>

	</div>
</template>

<script>
	  import * as links from '@/links'
	  import {weixi} from "@/api/script"
	  
	export default {
		name: 'forgetMess',  
		data (){
		 	return{
		 		
		 	}
		},
		created:function(){
			this.$store.dispatch("doLoginURL");
			weixi()			
		},
		updated:function(){
			var obj = new WxLogin({
				id: "QRcode",
				appid: links.APPID,
				scope: "snsapi_login",
				redirect_uri: links.REDIRECT_URL,
				href: '',
				state: "2018-1-16"
			});
		},
		computed:{
			loginUrl(){							 	
				return this.$store.getters.getLoginUrl
			},
		},
	}
</script>
<style lang="scss">
	.login{
		width: 100%;
		max-width: 1920px;
		margin: 0 auto;
		.background{
			position: fixed;
		    height: 100%;
		    width: 100%;
		    left: 0;
		    top: 0;
		}
	.middle{
		position: absolute;
		top: 128px;
		left: 50%;
		margin-left: -160px;
		}
	.login-con{
		background-color: #fff;
		width: 280px;
		border-radius: 6px;
		box-shadow: 0px 0px 4px 0px rgba(0,0,0,.3);	

	}
}
</style>
<style >
#QRcode iframe{
	margin-left: -10px;
}

</style>