<template>
	<div >		
		<transition name="el-fade-in" mode="out-in">
			<router-view></router-view>
		</transition>
	</div>
</template>

<script>
</script>

<style>
</style>
