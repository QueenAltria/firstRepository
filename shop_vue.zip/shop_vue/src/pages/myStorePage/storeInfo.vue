<template>
	<div>
		<div class="info_content clearfix" v-if="decorationShow">
			<router-link :to="{name:'storeMessShow'}" class="item-1 item-list fl">
				<div>
					<i class="iconfont icon-dianpuxinxi"></i>
					<span>店铺信息</span>
				</div>
				<p><i class="iconfont icon-dianpuxinxi"></i></p>
			</router-link>
			<router-link :to="{name:'shop_decoration'}" class="item-2 item-list fl">
				<div>
					<i class="iconfont icon-dianpuzhuangxiu"></i>
					<span>店铺装修</span>
				</div>
				<p><i class="iconfont icon-dianpuzhuangxiu"></i></p>
			</router-link>
			<router-link :to="{name:'freightSetting'}" class="item-3 item-list fl">
				<div>
					<i class="iconfont icon-dianpuzhuangxiu"></i>
					<span>运费设置</span>
				</div>
				<p><i class="iconfont icon-dianpuzhuangxiu"></i></p>
			</router-link>
		</div>
		<div class="none_mess text-c" v-if="decorationShow===false">
			<p class="color-3 f14">店铺信息不完善，请先添加店铺信息</p>
			<el-button class="store-button1 middle mt-40 px-30 " @click="addMess">
				添加店铺信息
			</el-button>
		</div>
	</div>
</template>

<script>
	import * as types from "@/store/mutation-types"
	import {getUserMess,getstoreMess} from "@/api/myStore"	
	import router from '@/router'
	export default {
		name: "my_store",
		data() {
			return {
				decorationShow: true,
			}
		},
		beforeRouteLeave(to,from,next){
			if(this.decorationShow===false){
				if(to.path==="/zxh/my_store_blank/addMess"||to.path==="/"){
					next();
				}else{
					this.$message('请点击添加店铺信息按钮');
					next(false);
				}
			}else{
				next();
			}			
		},
		created() {
			//保证店铺装修的信息不依赖店铺信息，这里直接获取一次信息
			let getter = this.$store.getters
			let id = getter.getMall_id;
			getUserMess(id)
				.then(({data}) => {									
					//没有数据时长度为0
					var len = data.length;
					this.decorationShow = len > 0 ? true : false;
					this.$store.commit(types.MESSLENGTH, len);
					if(len > 0) {
						var shop_id = data[0].shop_id;
						this.$store.commit(types.GETSHOPID, shop_id);
						//获取店铺装修商品分类数据
						this.$store.dispatch("doClassifyList", shop_id);
					};
				})
				.catch(({response: {data}})=>{
					this.$message.error(data.errorcmt);
				})	
		},
		methods: {
			addMess() {
				router.replace("/zxh/my_store_blank/addMess")
			},
		}
	}
</script>